import glob
import re

for slika in glob.glob('C:/Users/Vuk/Desktop/kosakra/ozbiljno/aplikacija/timovi/*.png'):
	img_ime=Image.open(slika).filename()

	url='https://www.basketball-reference.com/teams/'+img_ime+'/2020.html'
	requests.get(url)
	values={'s':'basics', 'submit':'search'}
	data=urllib.parse.urlencode(values)
	data=data.encode('utf-8')
	req=urllib.request.Request(url,data)
	resp=urllib.request.urlopen(req)
	respData=resp.read()

	imenaigraca=[]
	for i in range(0,4):
		igracihtml=re.findall(r'<tr ><th scope="row" class="center " data-stat="ranker" csk="." >.<\/th><td class="left " data-append-csv=".+?".+?csk=".+?>.+?>[A-Z].+?<', str(respData))
		print(igracihtml[i])
		paragraf=igracihtml[i][::-1]
		pravoime=''
		for i in range(1,40):
			if paragraf[i] == ">":
				break
			pravoime+=paragraf[i]
		pravoime=pravoime[::-1]
		print(pravoime)
		imenaigraca.append(pravoime)